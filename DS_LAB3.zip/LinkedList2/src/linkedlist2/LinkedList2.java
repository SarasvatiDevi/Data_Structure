/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package linkedlist2;

/**
 *
 * @author Sarasvati
 */
public class LinkedList2 {
     private int size;
     class Node{
        int data ;
        Node next;
        Node(int data){
           this.data=data;
           this.next=null;
        }
     }
     private Node head;
     LinkedList2(){
        head=null;
     }
     public void InsertAtStart(int data){
        
          Node newNode=new Node(data);
          newNode.next=head;
          head=newNode;
         size++;
     }
     public void InsertAtLast(int data){
          Node newNode=new Node(data);
         Node curr=head;
         
      while(curr.next!=null){
          curr=curr.next;
          
      }
      curr.next=newNode;
      size++;
     }
     public void InsertAtMiddle(int data,int pos){
         Node newNode=new Node(data);
         if(pos==0){
             newNode.next=head;
             head=newNode;
         }
         else{
             Node curr=head;
             
       for(int count=1;count<pos;count++){
           
             curr=curr.next;
       }  
          size++;
          newNode.next=curr.next;
         curr.next=newNode;
         }
     }
     public void delete(){
        if(head==null){
            System.out.println("List is empty");
            return;
        }
        size--;
        head=head.next;
     }
     public void deleteLast(){
      Node lastnode=head.next;
      Node secLast=head;
      while(lastnode.next!=null){
          lastnode=lastnode.next;
          secLast=secLast.next;
      }
      size--;
      secLast.next=null;
     }
    public void PrintAll(){
         Node curr=head;
         while(curr !=null){
             System.out.print(curr.data+"-->");
             curr=curr.next;
         }
         System.out.println(" ");
     }
    public int getSize(){
        return size;
    }
    public void Search(int key){
      Node num= head;
      boolean pos=false;
      int i=1;
      while(num!=null){
         if(num.data==key){
             System.out.println(num.data+" found");
             pos=true;
         }
         num=num.next;
         i++;
      }
      if(pos==false){
          System.out.println("not found");
      }
    }
    public void reverse(){
       Node prevNode =head;
       Node currNode=head.next;
       while(currNode !=null){
           Node nextNode=currNode.next;
           currNode.next=prevNode;
           
           prevNode=currNode;
           currNode=nextNode;
       }
       head.next=null;
       head=prevNode;
    }
    
       
   
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        LinkedList2 list=new LinkedList2();
        list.InsertAtStart(70);
        list.InsertAtStart(60);
        list.InsertAtStart(50);
        list.InsertAtStart(40);
        list.InsertAtStart(30);
        list.InsertAtStart(20);
        list.InsertAtStart(10);
        list.PrintAll();
        list.InsertAtLast(80);
        list.InsertAtLast(90);
        list.PrintAll();
         list.InsertAtMiddle(25,2);
        list.PrintAll();
        list.delete();
        list.PrintAll();
       list.deleteLast();
        list.PrintAll();
       list.reverse();
       list.PrintAll();
       System.out.println("size "+list.getSize());
        list.Search(30);
    }
    
}
