/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package bubblesorting;

/**
 *
 * @author Sarasvati
 */
import java.util.Scanner;
public class BubbleSorting {

    int[] arr = new int[10];

    String[] array = new String[100];
   //TASK NO: 1
    public void bubblesort(int[] arr) {
        int count=0;
        for (int i = 0; i < arr.length - 1; i++) {
            for (int j = 0; j < arr.length - 1; j++) {
                 count++;
                if (arr[j] > arr[j + 1]) {
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp; 
                }
            }
        }
         for (int i = 0; i < arr.length - 1; i++) {
            System.out.print(arr[i] + " ");
        }
         System.out.println("\ncount: "+count);
    }
    //TASK NO: 2
    public void bubblesortstepreduce(int[] arr) {
        int count=0;
        boolean swaped;
        for (int i = 0; i < arr.length - 1; i++) {
            swaped = false;
            for (int j = 0; j < arr.length - 1 - i; j++) {
                 count++;
                if (arr[j] > arr[j + 1]) {
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                    swaped = true;
                   
                }
            }
            if (swaped == false) {
                break; 
            }
        }
        System.out.println("count: "+count);

    }
//TASK NO: 3
    public void bubbleSortString(String[] arr) {
        for (int i = 0; i < arr.length - 1; i++) {
            for (int j = 0; j < arr.length - 1 - i; j++) {
                if (arr[j].length() > arr[j + 1].length()) {
                    String temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }

    }


    public void merge(int[] arr1, int[] arr2, int[] arr3) {
        int i = 0, j = 0, k = 0;
        int a = arr1.length;
        int b = arr2.length;
        while (i < a && j < b) {
            if (arr1[i] < arr2[j]) {
                arr3[k++] = arr1[i++];
            } else {
                arr3[k++] = arr2[j++];
            }
        }
        while (i < a) {
            arr3[k++] = arr1[i++];

        }
        while (j < b) {
            arr3[k++] = arr2[j++];
        }

    }
public void merge(int[] nums1, int m, int[] nums2, int n) {
        int i = m - 1; 
        int j = n - 1; 
        int k = m + n - 1; 
         while (i >= 0 && j >= 0) {
            if (nums1[i] > nums2[j]) {
                nums1[k] = nums1[i];
                i--;
            } else {
                nums1[k] = nums2[j];
                j--;
            }
            k--;
        }
       
        while (j >= 0) {
            nums1[k] = nums2[j];
            j--;
            k--;
        }
}
   


    public static void main(String[] args) {

        BubbleSorting b = new BubbleSorting();
        Scanner scan=new Scanner(System.in);
           
        int[] arr1 = {8, 75, 94, 3, 87, 45, 34, 90, 23, 44};
        String[] sarr = {"hello", "sanjina", "hi", "success"};
        System.out.println("Before sorting");
        for (int i = 0; i < arr1.length - 1; i++) {
            System.out.print(arr1[i] + " ");
        }
        System.out.println("\nAfter sorting");
        b.bubblesort(arr1);
        
       
        int array[] = {9, 3, 2, 5, 1, 11, 12, 13};
        //Reduce steps
        System.out.println("\nBefore reduce step");
         for (int i = 0; i < array.length; i++) {
            System.out.print(array[i] + " ");
        }
         System.out.println("\nreduce step");
        b.bubblesortstepreduce(array);
        
        
        System.out.println("\nBefore sorting");
        for (int i = 0; i < sarr.length; i++) {
            System.out.print(sarr[i] + " ");
        }
        b.bubbleSortString(sarr);
        System.out.println("\nAfter sorting");
        for (int i = 0; i < sarr.length; i++) {
            System.out.print(sarr[i] + " ");
        }
        System.out.println(" ");
        int num1[] = {2, 3, 4, 6, 8};
        int num2[] = {2, 5, 6};
        int num3[] = new int[num1.length + num2.length];
//        b.merge(num1,num2);
//        for(int i=0;i<num1.length;i++){
//            System.out.println(num1[i]);
//        }
        b.merge(num1, num2, num3);
        for (int i = 0; i < num3.length; i++) {
            System.out.print(num3[i]+" ");
        }
//        System.out.println("Merging leetcode question ");
//        int[] num4={1,2,3};
//       // b.merge(num4,3, num2, 3);
//        
//       for (int i = 0; i < num4.length; i++) {
//            System.out.println(num4[i]);
//        }
        
    }

}
