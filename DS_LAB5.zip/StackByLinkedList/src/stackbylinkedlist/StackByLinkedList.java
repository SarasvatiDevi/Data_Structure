/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package stackbylinkedlist;

/**
 *
 * @author Sarasvati
 */
public class StackByLinkedList {
     class Node{
        int data;
        Node next;
        Node(int data){
          this.data=data;
          next=null;
        }
     }
     private Node top;
     private int size;
     public int getsize(){
      return size;
     }
     StackByLinkedList(){
        top=null;
     }
     public boolean isEmpty(){
       return top==null;
     }
     public void push(int data){
        Node newNode=new Node(data);
        if(top==null){
         top=newNode;
         size++;
         return;
        }
        newNode.next=top;
        top=newNode;
        size++;
     }
     public int peek(){
       return top.data;
     }
     public int pop(){
         if(isEmpty()){
             System.out.println("stack is underflow");
          return -1;
         }
         size--;
        int temp=top.data;
            top=top.next;
            return temp;
     }
     
     public void display(){
       Node curr=top;
       while(curr!=null){
           System.out.println(curr.data);
           curr=curr.next;
       }
     }
    public static void main(String[] args) {
        // TODO code application logic here
        StackByLinkedList slist=new StackByLinkedList();
        slist.push(10);
        slist.push(20);
        slist.push(30);
        slist.push(40);
        System.out.println("Push values: ");
        slist.display();
         System.out.println("size after push: "+slist.getsize());
         System.out.println("Peek: "+ slist.peek());
        slist.pop();
        slist.pop();
        slist.pop();
        System.out.println("After pop: ");
        slist.display();
        System.out.println("After pop: "+slist.getsize());
        
       
        
    }
    
}
