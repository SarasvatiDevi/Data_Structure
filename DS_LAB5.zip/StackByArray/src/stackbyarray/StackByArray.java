/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package stackbyarray;

/**
 *
 * @author Sarasvati
 */
import java.util.Scanner;
public class StackByArray {
         int top;
         int cap;
         int array[];
         StackByArray(int size){
              array= new int[size];
              top=-1;
              cap=size;
              
         }
        int size;
         public int size(){
         return size;
         }
          public boolean isEmpty(){
           return top==-1;
          }
          public boolean isFull(){
              return top==cap-1;           
          }
          public void push(int data){
             if(isFull()){
                 System.out.println("stack is full");
                 return;
             }
              array[++top]=data;
              size++;
          }
         public int peek(){
             if(isEmpty()){
                 System.out.println("stack underflow");
                 return -1;
             }
           return array[top];
         }
         public int pop(){
            if(isEmpty()){
                 System.out.println("stack underflow");
                 return -1;
             }
              size--;
         return array[--top];
       
         }
         public void display(){
            for(int i=top;i>-1;i--){
                System.out.println(array[i]);
            }
         }
         
           
    public static void main(String[] args) {
        // TODO code application logic here
        StackByArray slist=new StackByArray(7);
        slist.push(1);
        slist.push(2);
        slist.push(3);
        slist.push(4);
        System.out.println("Push values: ");
        slist.display();
        System.out.println("Size After push: "+slist.size());
        System.out.println("peek: "+slist.peek());
        slist.pop();
        slist.pop();
        slist.pop();
        System.out.println("After pop: ");
        slist.display();
        System.out.println("size After pop: "+slist.size());
        }
    
}
