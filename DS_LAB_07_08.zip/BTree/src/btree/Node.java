/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package btree;

/**
 *
 * @author TGM
 */
public class Node {
    int data;
    Node left;
    Node right;

    public Node(int data) {
        this.data = data;
    }
    
    public void addRightChild(Node child, Node curr){
        curr.right = child;
    }
    public void addLeftChild(Node child, Node curr){
        curr.left = child;
    }
    
    public void preorder(Node node){
         if(node!=null){
    System.out.print(node.data + "->");
    preorder(node.left);
    preorder(node.right);    
    }
    }
    public void postorder(Node node){
      if(node!=null){
        postorder(node.left);
          postorder(node.right);
          System.out.print(node.data+"-->");
      }
    }
    public void inorder(Node node){
       if(node !=null){
        inorder(node.left);
           System.out.print(node.data+"->");
           inorder(node.right);
       }
    }
    public void levelorder(Node node, int level){
       if(node==null){
        return;
       }
       if(level==1){
           System.out.print(node.data+" ");
       }
       else if(level>1){
          // System.out.println(node.data);
         levelorder(node.left,level-1);
         levelorder(node.right,level-1);
       }
    }
     public void LevelOrderTraverse(Node node){
        int h=height(node);
        for(int i=1;i<=h;i++){
          levelorder(node,i);
            System.out.println();
        }
      }
    public int height(Node node){
      if(node==null){
       return 0;
      }
      int dl=height(node.left);
      int dr=height(node.right);
      return Math.max(dl,dr)+1;
    }
    public int totalnodes(Node node){
    if(node==null){
        return 0;
    }
    else{
      int l=totalnodes(node.left);
      int r=totalnodes(node.right);
      return 1+l+r;
    }
    
    }
}
