/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package btree;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

/**
 *
 * @author TGM
 */
public class BTree {
    
    Node root;

    public BTree(int data) {
        root = new Node(data);
    }
    
      public void preorderTraversal(){
           Stack<Node> s=new Stack<>();
          if(root==null){
             return;
          }
         Node curr=root;
         while(curr!=null || !s.isEmpty()){
             while(curr!=null){
                s.push(curr);
                System.out.println(s.peek().data);
                curr=curr.left;
             }
             curr=s.pop();
             curr = curr.right;
         }
 }
      
      public void postorderTraversal(){
        Stack<Node> s1=new Stack<>();
        Stack<Node> s2=new Stack<>();
        if(root!=null){
           s1.push(root);
        }
        while(!s1.isEmpty()){
          Node curr=s1.pop();
          s2.push(curr);
           if(curr.left!=null){
            s1.push(curr.left);
          }
          if(curr.right!=null){
             s1.push(curr.right);
          } 
        }
        //reverse order from s2
        while(!s2.isEmpty()){
            System.out.println(s2.pop().data+" ");
        }
       }
      public void inorderTraversal(){
        Stack<Node> s=new Stack<>();
        if(root==null){
            return;
        }
        Node curr=root;
        while(curr!=null || !s.isEmpty()){
          while(curr!=null){
           s.push(curr);
           curr=curr.left;
          }
          curr=s.pop();
            System.out.println(curr.data+" ");
            curr=curr.right;
        }
      }
      public void levelorderTraversal(){
        Queue<Node> q= new LinkedList<>();
        if(root==null){
          return;
        }
        q.add(root);
        q.add(null);
        while(!q.isEmpty()){
             Node curr=q.poll();
             if(curr==null){
                 System.out.println("");
             
             if(q.isEmpty()){
               break;
             }
             else{
               q.add(null);
             }
             }
             else{
              System.out.print(curr.data+" ");
              if(curr.left!=null){
              
              q.add(curr.left);
              }
              if(curr.right!=null){
               q.add(curr.right);
              }
             }
          }
      }
     
      
    public static void main(String[] args) {
        
        BTree tree = new BTree(1);//root
        
        Node root_left = new Node(2);//left
        Node root_right = new Node(3);//right
        Node root_left_left = new Node(4);
        Node root_left_right = new Node(5);
        Node root_right_left= new Node(6);
        Node root_right_right= new Node(7);
        Node root_left_left_left=new Node(8);
        Node root_left_left_right=new Node(9);
        Node root_left_right_left=new Node(10);
         Node root_left_right_right=new Node(11);
         Node root_right_left_left=new Node(12);
         Node root_right_left_right=new Node(13);
         Node root_right_right_left=new Node(14);
         Node root_right_right_right=new Node(15);
        //root child
        tree.root.addLeftChild(root_left , tree.root);//root-->left 2
        tree.root.addRightChild(root_right , tree.root);//root-->right  3
        
        //left child
        root_left.addLeftChild(root_left_left, root_left);//left-left child 4
        root_left.addRightChild(root_left_right, root_left);//left - right child 5
        //right child
        root_right.addLeftChild(root_right_left, root_right);//right -left child 6 
        root_right.addRightChild(root_right_right, root_right);//right -right child  7
        // left-left child
        root_left_left.addLeftChild(root_left_left_left, root_left_left); // left left-left child 8
        root_left_left.addRightChild(root_left_left_right, root_left_left);//left left-right child 9
        //left -right child
        root_left_right.addLeftChild(root_left_right_left, root_left_right); //left right-left child 10
        root_left_right.addRightChild(root_left_right_right, root_left_right);//left right-right child 11
        ///right-left child
        root_right_left.addLeftChild(root_right_left_left, root_right_left);// right left-left child 12
        root_right_left.addRightChild(root_right_left_right, root_right_left);// right left right child 13
        //right right child
        root_right_right.addLeftChild(root_right_right_left, root_right_right);//right right left child 14
        root_right_right.addRightChild(root_right_right_right, root_right_right);//right right right child 15
        //preOrder
            System.out.println("Pre order traversal with recursion:");
             tree.root.preorder(tree.root);
           System.out.println("");
           System.out.println("Pre order traversal with stack:");
            tree.preorderTraversal();
               System.out.println();
               //PostOrder
            System.out.println("post order traversal with recursion:");
            tree.root.postorder(tree.root);
             System.out.println();
           System.out.println("post order traversal with Stack:");
               tree.postorderTraversal();
               //Inorder
                System.out.println("In order traversal with recursion:");
            tree.root.inorder(tree.root);
             System.out.println();
              System.out.println("In order traversal with Stack:");
           tree.inorderTraversal();
             System.out.println();
             //Level Order
             System.out.println("Level order traversal with recursion:");
            tree.root.LevelOrderTraverse(tree.root);
             System.out.println();
              System.out.println("Levelorder traversal with Stack:");
           tree.levelorderTraversal();
             System.out.println();
             System.out.println("Total number of nodes: "+tree.root.totalnodes(tree.root));
             
    
    }

  
    
}
