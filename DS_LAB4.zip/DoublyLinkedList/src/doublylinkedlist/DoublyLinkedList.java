/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package doublylinkedlist;

/**
 *
 * @author Sarasvati
 */
public class DoublyLinkedList {
    class Node {
        int data;
        Node prev;
        Node next;
        
        Node(int data) {
            this.data = data;
            this.prev = null;
            this.next = null;
        }
    }
    private Node head;
    private Node tail;
    private int count;

    DoublyLinkedList() {
        this.head = null;
        this.tail = null;
    }

    public void InsertAtStart(int data) {
        Node newNode = new Node(data);
        newNode.next = head;
        if (head != null) {
            head.prev = newNode;
        }
        head = newNode;
        count++;
    }

    public void InsertAtEnd(int data) {
        Node newNode = new Node(data);
        Node curr = head;
        while (curr.next != null) {
            curr = curr.next;
        }
        curr.next = newNode;
        newNode.prev = curr;
        count++;
    }

    public void PrintAll() {
        Node curr = head;
        while (curr != null) {
            System.out.print(curr.data + " -->");
            curr = curr.next;
        }
        System.out.println(" ");
    }
    public void PrintFromEnd() {
        Node curr = tail;
        while (curr != null) {
            System.out.print(curr.data + " -->");
            curr = curr.prev;
        }
        System.out.println(" ");
    }

    public void InsertAtMiddle(int data, int pos) {
        Node newNode = new Node(data);
        if (pos == 1) {
            newNode.next = head;
            if (head != null) {
                head.prev = newNode;
            }
        }
        Node curr = head;
        for (int i = 1; i <= pos; i++) {
            curr = curr.next;
        }
        count++;
        newNode.prev = curr;
        newNode.next = curr.next;
        curr.next = newNode;
    }

    public void DeleteAtStart() {
        Node curr = head;
        curr = curr.next;
        if (curr != null) {
            curr.prev = null;
        }
        count--;
        head = head.next;
    }
   
    public void DeleteAtEnd() {

        Node curr;
        curr = head;
        while (curr.next != null) {
            curr = curr.next;
        }
        count--;
        curr.prev.next = null;

    }

    public void DeleteByValue(int val) {
        Node curr = head;
        while (curr != null) {
            if (curr.data == val) {
                  count--;
                if (curr.prev != null) {
                    curr.prev.next = curr.next;
                } else {
                    head = curr.next;
                }
                if (curr.next != null) {
                    curr.next.prev = curr.prev;
                } else {
                    tail = curr.prev.next;
                }
                return;
            }

            curr = curr.next;
        }
        System.out.println("not found");
    }

    public int size() {
        return count;
    }

    
    public void Search(int key){
        Node temp=head;
        boolean pos=true;
        int i=0;
        while(temp!=null){
           if(temp.data==key){
               System.out.println(i+" found");
               return;
           }
           temp=temp.next;
           i++;
        }
        System.out.println("not found");
        
    }
    public void reverse(){
       Node prevNode =head;
       Node currNode=head.next;
       while(currNode !=null){
           Node nextNode=currNode.next;
           currNode.next=prevNode;
           
           prevNode=currNode;
           currNode=nextNode;
       }
       head.next=null;
       head=prevNode;
    }
    public static void main(String[] args) {
        // TODO code application logic here
        DoublyLinkedList list = new DoublyLinkedList();
        list.InsertAtStart(5);
        list.InsertAtStart(4);
        list.InsertAtStart(3);
        list.InsertAtStart(2);
        list.InsertAtStart(1);
        System.out.println("from start");
        list.PrintAll();
        System.out.println("from end");
        list.PrintFromEnd();
        list.InsertAtEnd(6);
        list.PrintAll();
        list.InsertAtMiddle(10, 1);
        list.PrintAll();
        System.out.println("size "+list.size());
        list.DeleteAtStart();
        list.PrintAll();
        System.out.println("size "+list.size());
        list.DeleteAtEnd();
        list.PrintAll();
        System.out.println("size "+list.size());
        list.DeleteByValue(10);
        list.PrintAll();
        System.out.println("size "+list.size());
          list.Search(4);
          list.reverse();
          list.PrintAll();
        
                
    }

}
